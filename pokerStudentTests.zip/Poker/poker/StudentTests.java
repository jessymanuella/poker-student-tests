package poker;

import static org.junit.Assert.*;
import org.junit.Test;

public class StudentTests {

	@Test
	public void hasPairTest1() {
		Card[]cards = {new Card(3,3), new Card(10, 0), new Card(3,2), 
				new Card(7,3), 
				new Card(5,2)};
		//System.out.println(PokerHandEvaluator.hasPair(cards));
		assertTrue(PokerHandEvaluator.hasPair(cards));
	}
	@Test
	public void hasPairtest2() {
		Card[]cards = {new Card(1,3), new Card(10, 0), new Card(3,2), 
				new Card(7,3), 
				new Card(5,2)};
		//System.out.println(PokerHandEvaluator.hasPair(cards));
		assertFalse(PokerHandEvaluator.hasPair(cards));
	}
	@Test 
	public void hasPairTest3 () {
		Card [] card = {new Card(4,1), new Card(2,2), new Card(2,1), 
				new Card(13,2), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasPair(card));
	}
	@Test
	public void hasPairTest4() {
		Card [] card = {new Card(1,1), new Card(2,3), new Card(1,1), 
				new Card(13,2), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasPair(card));
	}
	@Test
	public void hasPairTest5() {
		Card [] card = {new Card(4,1), new Card(2,3), new Card(2,1), 
				new Card(1,1), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasPair(card));
	}
	@Test
	public void hasPairTest6() {
		Card [] card = {new Card(4,1), new Card(2,3), new Card(2,1), 
				new Card(13,2), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasPair(card));
	}
		
	@Test
	public void hasTwoPairTest1() {
		Card [] card = {new Card(4,1), new Card(4,1), new Card(2,1), 
				new Card(13,2), new Card(2,1)};
		assertTrue(PokerHandEvaluator.hasTwoPair(card));
	}
	@Test 
	public void hasTwoPairTest2() {
		Card [] card = {new Card(4,1), new Card(2,3), new Card(2,1), 
				new Card(13,2), new Card(1,1)};
		assertFalse(PokerHandEvaluator.hasTwoPair(card));
	}
	@Test
	public void hasTwoPairTest3() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(1,1), 
				new Card(1,1), new Card(11,1)};
		assertFalse(PokerHandEvaluator.hasTwoPair(card));
	}
	@Test 
	public void hasThreeOfAKindTest1() {
		Card [] card = {new Card(1,1), new Card(7,3), new Card(2,1), 
				new Card(13,2), new Card(11,1)};
		assertFalse(PokerHandEvaluator.hasThreeOfAKind(card));
	}
	@Test
	public void hasThreeOfAKindTest2() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(1,1), 
				new Card(13,2), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(card));	
	}
	@Test
	public void hasThreeOfAKindTest3() {
		Card [] card = {new Card(1,1), new Card(2,3), new Card(1,1), 
				new Card(13,2), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(card));
	}
	@Test
	public void hasThreeOfAKindTest4() {
		Card [] card = {new Card(4,1), new Card(3,3), new Card(3,3), 
				new Card(3,3), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(card));
	}
	@Test
	public void hasThreeOfAKindTest5() {
		Card [] card = {new Card(4,1), new Card(2,3), new Card(2,2), 
				new Card(2,2), new Card(2,2)};
		assertTrue(PokerHandEvaluator.hasThreeOfAKind(card));
	}
	@Test
	public void hasFourOfAKindTest1() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(1,1), 
				new Card(1,1), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasFourOfAKind(card));
	}
	@Test
	public void hasFourOfAKindTest2() {
		Card [] card = {new Card(1,1), new Card(7,3), new Card(1,1), 
				new Card(13,2), new Card(11,1)};
		assertFalse(PokerHandEvaluator.hasFourOfAKind(card));
	}
	@Test
	public void hasFourOfAKindTest3() {
		Card [] card = {new Card(1,1), new Card(3,3), new Card(3,3), 
				new Card(3,3), new Card(3,3)};
		assertTrue(PokerHandEvaluator.hasFourOfAKind(card));
	}
	@Test
	public void hasFourOfAKindTest4() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(2,1), 
				new Card(1,1), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasFourOfAKind(card));
	}
	@Test
	public void hasFourOfAKindTest5() {
		Card [] card = {new Card(1,1), new Card(2,3), new Card(1,1), 
				new Card(1,1), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasFourOfAKind(card));
	}
	@Test
	public void hasFullHouseTest1() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(1,1), 
				new Card(2,2), new Card(2,2)};
		assertTrue(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest2() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(1,1), 
				new Card(2,2), new Card(11,1)};
		assertFalse(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest3() {
		Card [] card = {new Card(4,1), new Card(1,1), new Card(1,1), 
				new Card(1,1), new Card(11,1)};
		assertFalse(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest4() {
		Card [] card = {new Card(1,1), new Card(2,3), new Card(2,1), 
				new Card(2,1), new Card(2,1)};
		assertFalse(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest5() {
		Card [] card = {new Card(1,1), new Card(2,1), new Card(2,1), 
				new Card(2,1), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest6() {
		Card [] card = {new Card(1,1), new Card(1,1), new Card(2,1), 
				new Card(2,1), new Card(2,1)};
		assertTrue(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFullHouseTest7() {
		Card [] card = {new Card(1,1), new Card(2,1), new Card(2,1), 
				new Card(1,1), new Card(1,1)};
		assertTrue(PokerHandEvaluator.hasFullHouse(card));
	}
	@Test
	public void hasFlushTest1() {
		Card [] card = {new Card(5,2), new Card(2,2), new Card(2,2), 
				new Card(13,2), new Card(11,2)};
		assertTrue(PokerHandEvaluator.hasFlush(card));
	}
	@Test
	public void hasFlushTest2() {
		Card [] card = { new Card( 5,3) , new Card(2,1), new Card(2,1), 
				new Card(3,2), new Card(5,1)};
		assertFalse(PokerHandEvaluator.hasFlush(card));
	}
	@Test
	public void hasStraightTest1() {
		Card [] card = { new Card( 9,0) , new Card(10,2), new Card(13,1), 
				new Card(12,3), new Card(11,1)};
		assertTrue(PokerHandEvaluator.hasStraight(card));
	}
	@Test
	public void hasStraightTest2() {
		Card [] card = { new Card( 5,1) , new Card(8,0), new Card(6,2), 
				new Card(7,3), new Card(10,1)};
		assertFalse(PokerHandEvaluator.hasStraight(card));
	}
	@Test
	public void hasStraightFlush1() {
		Card [] card = { new Card( 5,3) , new Card(6,3), new Card(8,3), 
				new Card(7,3), new Card(9,3)};
		assertTrue(PokerHandEvaluator.hasStraightFlush(card));
	}
	public void hasStraightFlushTest2() {
		Card [] card = { new Card( 5,1) , new Card(8,0), new Card(6,2), 
				new Card(7,3), new Card(9,1)};
		assertFalse(PokerHandEvaluator.hasStraightFlush(card));
	}

}